package jp.kokoroharebare.app;

import android.app.AlarmManager;
import android.content.BroadcastReceiver;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class ReminderReceiver extends BroadcastReceiver {
    private static final String CHANNEL = "kokoro_harebare_reminders";
    @Override public void onReceive(Context context, Intent intent) {
        String type = intent == null ? "morning" : intent.getStringExtra("type");
        if (type == null) type = "morning";
        String today = new SimpleDateFormat("yyyy-MM-dd", Locale.JAPAN).format(new Date());
        String submitted = context.getSharedPreferences("kokoro_harebare", Context.MODE_PRIVATE)
            .getString("submitted_date", "");
        boolean alreadySubmitted = today.equals(submitted);
        if ("noon".equals(type)) {
            // 12時は当日分が未入力の場合に限って通知する。
            if (!alreadySubmitted) showNotification(context, type, false);
        } else {
            // 8時は入力済み／未入力のどちらでも、状態に応じたメッセージを通知する。
            showNotification(context, type, alreadySubmitted);
        }
        scheduleNext(context);
    }

    private void showNotification(Context c, String type, boolean alreadySubmitted) {
        NotificationManager nm = (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(
            new NotificationChannel(CHANNEL, "記録リマインダー", NotificationManager.IMPORTANCE_DEFAULT));
        String body = "morning".equals(type)
            ? (alreadySubmitted
                ? "【入力済み】ですね。素晴らしいですね！🌈"
                : "【未入力】です。今日も無理せず、できるところから入力してね🍀")
            : "【未入力】です。今日も無理せず、できるところから入力してね🍀";
        Intent open = new Intent(c, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(c, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(c, CHANNEL) : new Notification.Builder(c);
        b.setSmallIcon(R.drawable.ic_notification_heart).setContentTitle("こころ晴れバレ")
            .setContentText(body).setAutoCancel(true).setContentIntent(pi);
        nm.notify(type.hashCode(), b.build());
    }

    static void schedule(Context c) { scheduleNext(c); }
    static void scheduleNext(Context c) {
        Calendar now = Calendar.getInstance();
        Calendar morning = (Calendar)now.clone();
        morning.set(Calendar.HOUR_OF_DAY, 8); morning.set(Calendar.MINUTE, 0);
        morning.set(Calendar.SECOND, 0); morning.set(Calendar.MILLISECOND, 0);
        if (!morning.after(now)) morning.add(Calendar.DAY_OF_YEAR, 1);
        Calendar noon = (Calendar)now.clone();
        noon.set(Calendar.HOUR_OF_DAY, 12); noon.set(Calendar.MINUTE, 0);
        noon.set(Calendar.SECOND, 0); noon.set(Calendar.MILLISECOND, 0);
        if (!noon.after(now)) noon.add(Calendar.DAY_OF_YEAR, 1);
        scheduleAt(c, morning, "morning");
        scheduleAt(c, noon, "noon");
    }
    private static void scheduleAt(Context c, Calendar time, String type) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        Intent in = new Intent(c, ReminderReceiver.class).putExtra("type", type);
        PendingIntent pi = PendingIntent.getBroadcast(c, type.hashCode(), in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (Build.VERSION.SDK_INT >= 23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time.getTimeInMillis(), pi);
            else am.setExact(AlarmManager.RTC_WAKEUP, time.getTimeInMillis(), pi);
        } catch (SecurityException e) {
            // Exact alarm access may be disabled by the system; use a battery-friendly fallback.
            if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time.getTimeInMillis(), pi);
            else am.set(AlarmManager.RTC_WAKEUP, time.getTimeInMillis(), pi);
        }
    }
}
